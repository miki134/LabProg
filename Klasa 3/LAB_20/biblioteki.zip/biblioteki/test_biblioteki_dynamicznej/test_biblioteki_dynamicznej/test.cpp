#include <test1.h>

int main()
{
	int s = suma(10, 17);
}