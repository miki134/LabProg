#include <test2.h>
int main()
{
	int s = suma(10, 17);
}