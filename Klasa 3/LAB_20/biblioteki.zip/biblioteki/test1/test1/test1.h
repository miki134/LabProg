#pragma once
int suma(int a, int b);
