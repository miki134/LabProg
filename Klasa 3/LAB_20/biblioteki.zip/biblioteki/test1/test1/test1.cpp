#include "test1.h"

int suma(int a, int b)
{
	return a + b;
}